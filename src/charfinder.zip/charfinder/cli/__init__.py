"""
CLI package for CharFinder.

This package implements the command-line interface.
No public API is exposed at this level.
"""
